var defaultMenu = function() {

options = {
  "" : "A. View the existing cart.",
  "" : "B. Select Delivery slot to place order."
};

}

function Option(optionId, optionKey, optionType, optionDescription, optionMetadata) { 
    this.optionId = optionId;
    this.optionKey = optionKey;
    this.optionType = optionType;
    this.optionDescription = optionDescription;
    this.optionMetadata = optionMetadata;
 }
module.exports.Option = Option;

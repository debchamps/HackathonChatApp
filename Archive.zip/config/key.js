module.exports = {
  googleClientID : '282174529589-t8467e3t9ij3dfsfr4p05ropojn3hc5n.apps.googleusercontent.com',
  googleClientSecret: 'hB2XVe2T9AoFQsLxWKxETX5e',
  facebookClientId: '2066712160260144',
  facebookClientSecret : '50ce5b7832f531a624754852642e6161',
  mongoUri: 'mongodb://debarghy:password123@ds239940.mlab.com:39940/emaily-debarghy',
  cookieKey: 'efergryyhrytdfhgthtfhnjgntdgbdrtgbntyjntybvfrbtynyun',
  awsAccessKeyId: 'AKIAICT757BCR7J7RXBA',
  awsSecretKey : '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'
}
